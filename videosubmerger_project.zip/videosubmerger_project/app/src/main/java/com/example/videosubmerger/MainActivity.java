package com.example.videosubmerger;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.arthenica.mobileffmpeg.FFmpeg;
import com.arthenica.mobileffmpeg.Config;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_VIDEO = 1001;
    private static final int PICK_SUB = 1002;

    private Uri videoUri = null;
    private Uri subUri = null;

    private TextView statusTv;
    private Button pickVideoBtn, pickSubBtn, mergeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        }, 1);

        statusTv = findViewById(R.id.statusTv);
        pickVideoBtn = findViewById(R.id.pickVideo);
        pickSubBtn = findViewById(R.id.pickSub);
        mergeBtn = findViewById(R.id.mergeBtn);

        pickVideoBtn.setOnClickListener(v -> pickFile(PICK_VIDEO, "video/*"));
        pickSubBtn.setOnClickListener(v -> pickFile(PICK_SUB, "text/*"));

        mergeBtn.setOnClickListener(v -> {
            if (videoUri == null || subUri == null) {
                Toast.makeText(this, "الرجاء اختيار الفيديو وملف الترجمة أولاً", Toast.LENGTH_SHORT).show();
                return;
            }
            mergeProcess();
        });
    }

    private void pickFile(int req, String type) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        startActivityForResult(i, req);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null) {
            Uri u = data.getData();
            if (requestCode == PICK_VIDEO) {
                videoUri = u;
                statusTv.setText("✅ تم اختيار الفيديو");
            } else if (requestCode == PICK_SUB) {
                subUri = u;
                statusTv.setText("✅ تم اختيار ملف الترجمة");
            }
        }
    }

    // Copy URI to file
    private File copyUriToFile(Uri uri, String name) throws Exception {
        InputStream is = getContentResolver().openInputStream(uri);
        File out = new File(getCacheDir(), name);
        BufferedInputStream bis = new BufferedInputStream(is);
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(out));
        byte[] buf = new byte[4096];
        int len;
        while ((len = bis.read(buf)) > 0) {
            bos.write(buf, 0, len);
        }
        bos.flush();
        bos.close();
        bis.close();
        return out;
    }

    // Try to convert subtitle file to UTF-8 if needed (simple heuristic)
    private File ensureUtf8(File inFile) throws Exception {
        byte[] data = new byte[(int) inFile.length()];
        FileInputStream fis = new FileInputStream(inFile);
        fis.read(data);
        fis.close();
        String utf = new String(data, Charset.forName("UTF-8"));
        if (utf.contains("\uFFFD")) { // replacement char present -> likely wrong decode
            // try windows-1256 (common for Arabic)
            String win = new String(data, Charset.forName("windows-1256"));
            File out = new File(getCacheDir(), "subs_utf8.srt");
            FileOutputStream fos = new FileOutputStream(out);
            fos.write(win.getBytes(Charset.forName("UTF-8")));
            fos.close();
            return out;
        } else {
            // already UTF-8 - return original
            return inFile;
        }
    }

    private void mergeProcess() {
        statusTv.setText("⏳ جاري التحضير...");
        new Thread(() -> {
            try {
                File vid = copyUriToFile(videoUri, "input_video.mp4");
                File subs = copyUriToFile(subUri, "input_subs.srt");

                // ensure utf-8
                File subsUtf = ensureUtf8(subs);

                // prepare output dir
                File outDir = new File(Environment.getExternalStorageDirectory(), "VideoSubMerger");
                if (!outDir.exists()) outDir.mkdirs();
                File outFile = new File(outDir, "output_" + System.currentTimeMillis() + ".mp4");

                // Build ffmpeg command (charenc to ensure Arabic)
                String cmd = String.format("-y -i %s -vf subtitles=%s:charenc=UTF-8 -c:a copy %s",
                        quote(vid.getAbsolutePath()), quote(subsUtf.getAbsolutePath()), quote(outFile.getAbsolutePath())
                );

                runOnUiThread(() -> statusTv.setText("🚀 جاري الدمج..."));
                int rc = FFmpeg.execute(cmd);
                if (rc == Config.RETURN_CODE_SUCCESS) {
                    runOnUiThread(() -> {
                        statusTv.setText("🎉 تم الدمج! الملف في: " + outFile.getAbsolutePath());
                        Toast.makeText(MainActivity.this, "تم الحفظ في VideoSubMerger", Toast.LENGTH_LONG).show();
                    });
                } else {
                    runOnUiThread(() -> {
                        statusTv.setText("❌ فشل الدمج، راجع السجل."); 
                        Toast.makeText(MainActivity.this, "فشل الدمج", Toast.LENGTH_LONG).show();
                        Log.e("FFMPEG", "rc="+rc);
                    });
                }

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> statusTv.setText("⚠️ خطأ: " + e.getMessage()));
            }
        }).start();
    }

    private String quote(String s) {
        return '"' + s + '"';
    }
}
