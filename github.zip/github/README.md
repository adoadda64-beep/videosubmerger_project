# VideoSubMerger - Android Project (Arabic UI)

تطبيق بسيط لدمج ترجمات SRT (بالعربية) داخل الفيديو (hardcoded) مع محاولة تحويل الترجمة أوتوماتيكياً إلى UTF-8 قبل الدمج.

**ملاحظات:**
- افتح المشروع في Android Studio (File → Open → مجلد المشروع).
- تأكد من وجود Android SDK وJava المناسبة.
- لتنزيل الاعتماديات، يجب اتصال بالإنترنت أول مرة (Gradle سيحمّل mobile-ffmpeg).

**Build:** Build -> Build Bundle(s) / APK(s) -> Build APK(s)
**Output APK:** app/build/outputs/apk/debug/app-debug.apk
